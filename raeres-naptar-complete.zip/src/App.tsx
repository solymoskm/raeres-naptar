import React from 'react';
export default function App() {
  return <div style={{ padding: '2rem' }}>Hello Naptár ✔️</div>;
}