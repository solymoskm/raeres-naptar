import React from 'react';

export default function App() {
  return (
    <div style={{ padding: '2rem', fontSize: '1.5rem' }}>
      Ráérés naptár működik! ✅
    </div>
  );
}
